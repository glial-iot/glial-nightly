require('fio').chdir('/usr/share/tarantool/glial')
require('glial').start()
